import { Component, OnInit } from '@angular/core';
import data from '../../data/accountdetails.json';
@Component({
  selector: 'app-viewallaccount',
  templateUrl: './viewallaccount.component.html',
  styleUrls: ['./viewallaccount.component.css']
})
export class ViewallaccountComponent implements OnInit {
  array=data
  constructor() { }

  ngOnInit() {
  }

}
